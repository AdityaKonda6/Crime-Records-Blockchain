import React, { Component } from 'react';
import Login from './Login'

class Home extends Component {
    render() 
    {
        return(
            <div>
                <Login/>
            </div>
        )

    }
}

export default Home;