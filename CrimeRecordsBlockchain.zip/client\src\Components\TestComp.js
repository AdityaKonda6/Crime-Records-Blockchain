import React, { Component } from 'react';

class TestComp extends Component {
    render(){
        return(
            <div >
                <h1>Hello</h1>
            </div>
        )
    }
}
export default TestComp;